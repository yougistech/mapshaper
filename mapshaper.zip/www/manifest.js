/* This file can contain files and import options; see mapshaper-gui; example:
mapshaper.manifest = {
  files: [],
  quick_view: true,
  commands: ""
};
*/